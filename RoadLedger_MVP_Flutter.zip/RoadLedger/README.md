
# RoadLedger (MVP)

Flutter + Hive offline-first Rent-a-Car income tracker.

## Quick Start

1) Install Flutter (3.22+).
2) Open this folder in VS Code or run in terminal:

```bash
flutter pub get
flutter create .  # generates missing platform folders (android/ios) if needed
flutter run       # test on emulator/device
```

## Build APK (release)

```bash
flutter build apk --release
# Output: build/app/outputs/flutter-apk/app-release.apk
```

If `android/` folder not present, run `flutter create .` once to scaffold it.

## Features

- Profile setup (business name, currency)
- Add cars (name/type/plate)
- Daily logs with expenses (pre-seeded Gas) & earnings (pre-seeded Base Fare)
- Automatic totals and net per day
- Monthly summary (earnings, expenses, net)
- Maintenance per month (tyre/suspension/etc)

## Notes

- Uses Hive (no native DB setup) -> simple, fast
- Amounts stored as minor units (cents)
- This is a minimal MVP scaffold to get you building & shipping fast.
