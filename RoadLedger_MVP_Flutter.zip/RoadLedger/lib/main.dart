import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';
import 'package:intl/intl.dart';

import 'models/models.dart';
import 'screens/car_list_screen.dart';
import 'screens/profile_setup_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  Hive.registerAdapter(ProfileAdapter());
  Hive.registerAdapter(CarAdapter());
  Hive.registerAdapter(DailyLogAdapter());
  Hive.registerAdapter(LineItemAdapter());
  Hive.registerAdapter(MaintenanceItemAdapter());
  Hive.registerAdapter(MaintenanceAdapter());

  await Hive.openBox<Profile>('profileBox');
  await Hive.openBox<Car>('cars');
  await Hive.openBox<DailyLog>('logs');
  await Hive.openBox<Maintenance>('maint');

  runApp(const RoadLedgerApp());
}

class RoadLedgerApp extends StatelessWidget {
  const RoadLedgerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'RoadLedger',
      theme: ThemeData(
        colorSchemeSeed: const Color(0xFF0145FF),
        useMaterial3: true,
        brightness: Brightness.light,
      ),
      darkTheme: ThemeData(
        colorSchemeSeed: const Color(0xFF0145FF),
        useMaterial3: true,
        brightness: Brightness.dark,
      ),
      home: const _Gate(),
    );
  }
}

class _Gate extends StatelessWidget {
  const _Gate();

  @override
  Widget build(BuildContext context) {
    final profileBox = Hive.box<Profile>('profileBox');
    final hasProfile = profileBox.isNotEmpty;
    return hasProfile ? const CarListScreen() : const ProfileSetupScreen();
  }
}
