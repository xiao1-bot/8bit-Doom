import 'package:hive/hive.dart';
part 'profile.g.dart';

@HiveType(typeId: 0)
class Profile extends HiveObject {
  @HiveField(0)
  String businessName;

  @HiveField(1)
  String? ownerName;

  @HiveField(2)
  String currency; // e.g., BDT

  @HiveField(3)
  DateTime createdAt;

  Profile({
    required this.businessName,
    this.ownerName,
    this.currency = 'BDT',
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();
}
