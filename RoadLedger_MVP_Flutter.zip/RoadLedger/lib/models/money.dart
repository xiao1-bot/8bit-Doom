import 'package:intl/intl.dart';

String formatMoney(int minor, {String currency = '৳'}) {
  final n = NumberFormat.currency(symbol: currency, decimalDigits: 2);
  return n.format(minor / 100);
}
