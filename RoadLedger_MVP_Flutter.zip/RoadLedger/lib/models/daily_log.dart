import 'package:hive/hive.dart';
part 'daily_log.g.dart';

@HiveType(typeId: 2)
class DailyLog extends HiveObject {
  @HiveField(0)
  String id;

  @HiveField(1)
  String carId;

  @HiveField(2)
  DateTime date;

  @HiveField(3)
  String routeFrom;

  @HiveField(4)
  String routeTo;

  @HiveField(5)
  List<LineItem> expenses;

  @HiveField(6)
  List<LineItem> earnings;

  DailyLog({
    required this.id,
    required this.carId,
    required this.date,
    required this.routeFrom,
    required this.routeTo,
    List<LineItem>? expenses,
    List<LineItem>? earnings,
  })  : expenses = expenses ?? [],
        earnings = earnings ?? [];

  int get totalExpensesMinor =>
      expenses.fold(0, (p, e) => p + (e.amountMinor));
  int get totalEarningsMinor =>
      earnings.fold(0, (p, e) => p + (e.amountMinor));
  int get net => totalEarningsMinor - totalExpensesMinor;

  String get monthKey => "${date.year.toString().padLeft(4,'0')}-${date.month.toString().padLeft(2,'0')}";
}

@HiveType(typeId: 3)
class LineItem {
  @HiveField(0)
  String category; // Gas, Toll, Driver, Parking, Other OR label for earning

  @HiveField(1)
  String? label;

  @HiveField(2)
  int amountMinor; // store as minor units

  LineItem({required this.category, this.label, required this.amountMinor});
}
