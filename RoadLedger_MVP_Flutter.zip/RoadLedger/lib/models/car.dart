import 'package:hive/hive.dart';
part 'car.g.dart';

@HiveType(typeId: 1)
class Car extends HiveObject {
  @HiveField(0)
  String id;

  @HiveField(1)
  String name;

  @HiveField(2)
  String type;

  @HiveField(3)
  String numberPlate;

  @HiveField(4)
  String? notes;

  @HiveField(5)
  bool archived;

  @HiveField(6)
  DateTime createdAt;

  Car({
    required this.id,
    required this.name,
    required this.type,
    required this.numberPlate,
    this.notes,
    this.archived = false,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();
}
