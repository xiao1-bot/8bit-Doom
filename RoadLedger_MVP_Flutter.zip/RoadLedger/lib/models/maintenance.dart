import 'package:hive/hive.dart';
part 'maintenance.g.dart';

@HiveType(typeId: 4)
class MaintenanceItem {
  @HiveField(0)
  String category; // Tyre, Suspension, Oil, Battery, Service, Other

  @HiveField(1)
  String? label;

  @HiveField(2)
  int amountMinor;

  MaintenanceItem({required this.category, this.label, required this.amountMinor});
}

@HiveType(typeId: 5)
class Maintenance extends HiveObject {
  @HiveField(0)
  String id;

  @HiveField(1)
  String carId;

  @HiveField(2)
  String month; // YYYY-MM

  @HiveField(3)
  List<MaintenanceItem> items;

  Maintenance({
    required this.id,
    required this.carId,
    required this.month,
    List<MaintenanceItem>? items,
  }) : items = items ?? [];

  int get totalMaintenanceMinor =>
      items.fold(0, (p, e) => p + e.amountMinor);
}
