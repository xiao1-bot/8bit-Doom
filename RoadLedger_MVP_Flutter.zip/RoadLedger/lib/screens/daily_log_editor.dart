import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';
import '../models/models.dart';

class DailyLogEditor extends StatefulWidget {
  final Car car;
  final DailyLog? existing;
  const DailyLogEditor({super.key, required this.car, this.existing});

  @override
  State<DailyLogEditor> createState() => _DailyLogEditorState();
}

class _DailyLogEditorState extends State<DailyLogEditor> {
  late DateTime _date;
  final _from = TextEditingController();
  final _to = TextEditingController();
  List<LineItem> _expenses = [];
  List<LineItem> _earnings = [];

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _date = e?.date ?? DateTime.now();
    _from.text = e?.routeFrom ?? '';
    _to.text = e?.routeTo ?? '';
    _expenses = List.from(e?.expenses ?? [LineItem(category: 'Gas', amountMinor: 0)]);
    _earnings = List.from(e?.earnings ?? [LineItem(category: 'Base Fare', amountMinor: 0)]);
  }

  @override
  Widget build(BuildContext context) {
    final totalExp = _expenses.fold<int>(0, (p, e) => p + e.amountMinor);
    final totalEarn = _earnings.fold<int>(0, (p, e) => p + e.amountMinor);
    final net = totalEarn - totalExp;
    return Scaffold(
      appBar: AppBar(title: Text(widget.existing == null ? 'Add Daily Entry' : 'Edit Daily Entry')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Text("Date: "),
                TextButton(
                  onPressed: () async {
                    final d = await showDatePicker(
                      context: context,
                      firstDate: DateTime(2020),
                      lastDate: DateTime(2100),
                      initialDate: _date,
                    );
                    if (d != null) setState(() => _date = d);
                  },
                  child: Text(_date.toLocal().toString().split(' ').first),
                ),
              ],
            ),
            TextField(
              controller: _from,
              decoration: const InputDecoration(labelText: 'From (Location)'),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _to,
              decoration: const InputDecoration(labelText: 'To (Location)'),
            ),
            const SizedBox(height: 16),
            Text('Expenses', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            ..._expenses.asMap().entries.map((e) => _lineItemRow(
              index: e.key, isExpense: true, item: e.value)),
            TextButton.icon(
              onPressed: () => setState(() => _expenses.add(LineItem(category: 'Other', amountMinor: 0))),
              icon: const Icon(Icons.add),
              label: const Text('Add Expense'),
            ),
            Align(
              alignment: Alignment.centerRight,
              child: Text("Total: ${(totalExp/100).toStringAsFixed(2)}"),
            ),
            const SizedBox(height: 16),
            Text('Earnings', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            ..._earnings.asMap().entries.map((e) => _lineItemRow(
              index: e.key, isExpense: false, item: e.value)),
            TextButton.icon(
              onPressed: () => setState(() => _earnings.add(LineItem(category: 'Extra', amountMinor: 0))),
              icon: const Icon(Icons.add),
              label: const Text('Add Earning'),
            ),
            Align(
              alignment: Alignment.centerRight,
              child: Text("Total: ${(totalEarn/100).toString().padRight(4, '0')}"),
            ),
            const Divider(height: 32),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Net'),
                Text((net/100).toStringAsFixed(2),
                  style: TextStyle(color: net >= 0 ? Colors.green : Colors.red)),
              ],
            ),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: _save,
              child: const Text('Save'),
            )
          ],
        ),
      ),
    );
  }

  Widget _lineItemRow({required int index, required bool isExpense, required LineItem item}) {
    final catController = TextEditingController(text: item.category);
    final amtController = TextEditingController(text: (item.amountMinor/100).toStringAsFixed(2));
    final labelController = TextEditingController(text: item.label ?? '');
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          SizedBox(
            width: 110,
            child: TextField(
              controller: catController,
              decoration: const InputDecoration(labelText: 'Category'),
              onChanged: (v) => item.category = v,
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: TextField(
              controller: labelController,
              decoration: const InputDecoration(labelText: 'Label (optional)'),
              onChanged: (v) => item.label = v.isEmpty ? null : v,
            ),
          ),
          const SizedBox(width: 8),
          SizedBox(
            width: 110,
            child: TextField(
              controller: amtController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(labelText: 'Amount'),
              onChanged: (v) {
                final parsed = double.tryParse(v.replaceAll(',', '')) ?? 0.0;
                item.amountMinor = (parsed * 100).round();
                setState(() {});
              },
            ),
          ),
          IconButton(
            onPressed: () {
              setState(() {
                if (isExpense) {
                  _expenses.removeAt(index);
                } else {
                  _earnings.removeAt(index);
                }
              });
            },
            icon: const Icon(Icons.delete_outline),
          )
        ],
      ),
    );
  }

  void _save() {
    if (_from.text.trim().isEmpty || _to.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Route fields are required'))
      );
      return;
    }
    final logs = Hive.box<DailyLog>('logs');
    final exists = logs.values.any((l) =>
      l.carId == widget.car.id &&
      l.date.year == _date.year &&
      l.date.month == _date.month &&
      l.date.day == _date.day &&
      (widget.existing == null || l.key != widget.existing!.key));
    if (exists) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('A log for this date already exists.'))
      );
      return;
    }
    if (widget.existing == null) {
      final log = DailyLog(
        id: const Uuid().v4(),
        carId: widget.car.id,
        date: _date,
        routeFrom: _from.text.trim(),
        routeTo: _to.text.trim(),
        expenses: _expenses,
        earnings: _earnings,
      );
      logs.put(log.id, log);
    } else {
      widget.existing!
        ..date = _date
        ..routeFrom = _from.text.trim()
        ..routeTo = _to.text.trim()
        ..expenses = _expenses
        ..earnings = _earnings
        ..save();
    }
    Navigator.pop(context);
  }
}
