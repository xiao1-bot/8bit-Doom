import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import '../models/models.dart';
import 'daily_log_editor.dart';
import 'maintenance_screen.dart';
import 'monthly_summary_screen.dart';

class CarScreen extends StatefulWidget {
  final Car car;
  const CarScreen({super.key, required this.car});

  @override
  State<CarScreen> createState() => _CarScreenState();
}

class _CarScreenState extends State<CarScreen> with SingleTickerProviderStateMixin {
  late String monthKey;
  late TabController _tab;

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    monthKey = "${now.year.toString().padLeft(4,'0')}-${now.month.toString().padLeft(2,'0')}";
    _tab = TabController(length: 3, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("${widget.car.name} • ${widget.car.numberPlate}"),
        bottom: TabBar(
          controller: _tab,
          tabs: const [
            Tab(text: "Daily Logs"),
            Tab(text: "Summary"),
            Tab(text: "Maintenance"),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tab,
        children: [
          _DailyLogsTab(car: widget.car, monthKey: monthKey),
          MonthlySummaryScreen(car: widget.car, monthKey: monthKey),
          MaintenanceScreen(car: widget.car, monthKey: monthKey),
        ],
      ),
      floatingActionButton: _tab.index == 0
        ? FloatingActionButton(
            onPressed: () async {
              await Navigator.of(context).push(MaterialPageRoute(
                builder: (_) => DailyLogEditor(car: widget.car)));
              setState(() {});
            },
            child: const Icon(Icons.add),
          )
        : null,
    );
  }
}

class _DailyLogsTab extends StatefulWidget {
  final Car car;
  final String monthKey;
  const _DailyLogsTab({required this.car, required this.monthKey});

  @override
  State<_DailyLogsTab> createState() => _DailyLogsTabState();
}

class _DailyLogsTabState extends State<_DailyLogsTab> {
  @override
  Widget build(BuildContext context) {
    final logsBox = Hive.box<DailyLog>('logs');
    final logs = logsBox.values
        .where((l) => l.carId == widget.car.id && l.monthKey == widget.monthKey)
        .toList()
      ..sort((a,b) => a.date.compareTo(b.date));
    if (logs.isEmpty) {
      return const Center(child: Text('No trips this month. Add a daily entry.'));
    }
    return ListView.separated(
      itemCount: logs.length,
      separatorBuilder: (_, __) => const Divider(height: 0),
      itemBuilder: (context, i) {
        final l = logs[i];
        final net = l.net / 100.0;
        return ListTile(
          title: Text("${l.routeFrom} → ${l.routeTo}"),
          subtitle: Text("${l.date.toLocal().toString().split(' ').first}"),
          trailing: Text(
            (net >= 0 ? "+" : "") + net.toStringAsFixed(2),
            style: TextStyle(color: net >= 0 ? Colors.green : Colors.red),
          ),
          onTap: () async {
            await Navigator.of(context).push(MaterialPageRoute(
              builder: (_) => DailyLogEditor(car: widget.car, existing: l)));
            setState(() {});
          },
        );
      },
    );
  }
}
