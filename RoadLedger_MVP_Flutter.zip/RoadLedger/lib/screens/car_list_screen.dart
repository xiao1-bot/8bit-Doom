import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:uuid/uuid.dart';
import '../models/models.dart';
import 'car_screen.dart';

class CarListScreen extends StatelessWidget {
  const CarListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Your Cars')),
      body: ValueListenableBuilder(
        valueListenable: Hive.box<Car>('cars').listenable(),
        builder: (context, Box<Car> box, _) {
          final cars = box.values.where((c) => !c.archived).toList();
          if (cars.isEmpty) {
            return const Center(child: Text('No cars yet. Add your first car.'));
          }
          return ListView.separated(
            itemCount: cars.length,
            separatorBuilder: (_, __) => const Divider(height: 0),
            itemBuilder: (context, i) {
              final c = cars[i];
              return ListTile(
                title: Text("${c.name} • ${c.type}"),
                subtitle: Text(c.numberPlate),
                onTap: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => CarScreen(car: c))
                  );
                },
                trailing: PopupMenuButton<String>(
                  onSelected: (v) {
                    if (v == 'archive') {
                      c.archived = true;
                      c.save();
                    } else if (v == 'edit') {
                      _showAddCarSheet(context, initial: c);
                    }
                  },
                  itemBuilder: (_) => [
                    const PopupMenuItem(value: 'edit', child: Text('Edit')),
                    const PopupMenuItem(value: 'archive', child: Text('Archive')),
                  ],
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddCarSheet(context),
        child: const Icon(Icons.add),
      ),
    );
  }

  Future<void> _showAddCarSheet(BuildContext context, {Car? initial}) async {
    final name = TextEditingController(text: initial?.name ?? '');
    final type = TextEditingController(text: initial?.type ?? '');
    final plate = TextEditingController(text: initial?.numberPlate ?? '');
    final form = GlobalKey<FormState>();
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(ctx).viewInsets.bottom + 16,
          left: 16, right: 16, top: 12),
        child: Form(
          key: form,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(initial == null ? 'Add Car' : 'Edit Car',
                style: Theme.of(ctx).textTheme.titleLarge),
              const SizedBox(height: 12),
              TextFormField(
                controller: name,
                decoration: const InputDecoration(labelText: 'Car Name'),
                validator: (v) => v==null || v.trim().isEmpty ? 'Required' : null,
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: type,
                decoration: const InputDecoration(labelText: 'Car Type (Sedan, MPV...)'),
                validator: (v) => v==null || v.trim().isEmpty ? 'Required' : null,
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: plate,
                decoration: const InputDecoration(labelText: 'Number Plate'),
                validator: (v) => v==null || v.trim().isEmpty ? 'Required' : null,
              ),
              const SizedBox(height: 12),
              FilledButton(
                onPressed: () {
                  if (!form.currentState!.validate()) return;
                  final box = Hive.box<Car>('cars');
                  if (initial == null) {
                    final car = Car(
                      id: const Uuid().v4(),
                      name: name.text.trim(),
                      type: type.text.trim(),
                      numberPlate: plate.text.trim(),
                    );
                    box.put(car.id, car);
                  } else {
                    initial
                      ..name = name.text.trim()
                      ..type = type.text.trim()
                      ..numberPlate = plate.text.trim();
                    initial.save();
                  }
                  Navigator.pop(ctx);
                },
                child: const Text('Save'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
