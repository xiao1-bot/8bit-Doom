import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import '../models/profile.dart';
import 'car_list_screen.dart';

class ProfileSetupScreen extends StatefulWidget {
  const ProfileSetupScreen({super.key});

  @override
  State<ProfileSetupScreen> createState() => _ProfileSetupScreenState();
}

class _ProfileSetupScreenState extends State<ProfileSetupScreen> {
  final _formKey = GlobalKey<FormState>();
  final _business = TextEditingController();
  final _owner = TextEditingController();
  String _currency = 'BDT';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create Profile')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _business,
                decoration: const InputDecoration(labelText: 'Business Name'),
                validator: (v) => (v==null || v.trim().isEmpty) ? 'Required' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _owner,
                decoration: const InputDecoration(labelText: 'Owner Name (optional)'),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: _currency,
                decoration: const InputDecoration(labelText: 'Currency'),
                items: const [
                  DropdownMenuItem(value: 'BDT', child: Text('BDT (৳)')),
                  DropdownMenuItem(value: 'USD', child: Text('USD ($)')),
                  DropdownMenuItem(value: 'EUR', child: Text('EUR (€)')),
                ],
                onChanged: (v) => setState(() => _currency = v ?? 'BDT'),
              ),
              const Spacer(),
              FilledButton.tonal(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    final box = Hive.box<Profile>('profileBox');
                    box.put('profile', Profile(
                      businessName: _business.text.trim(),
                      ownerName: _owner.text.trim().isEmpty ? null : _owner.text.trim(),
                      currency: _currency,
                    ));
                    Navigator.of(context).pushReplacement(
                      MaterialPageRoute(builder: (_) => const CarListScreen())
                    );
                  }
                },
                child: const Text('Save & Continue'),
              )
            ],
          ),
        ),
      ),
    );
  }
}
