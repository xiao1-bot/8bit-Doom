import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import '../models/models.dart';

class MonthlySummaryScreen extends StatelessWidget {
  final Car car;
  final String monthKey;
  const MonthlySummaryScreen({super.key, required this.car, required this.monthKey});

  @override
  Widget build(BuildContext context) {
    final logs = Hive.box<DailyLog>('logs').values
      .where((l) => l.carId == car.id && l.monthKey == monthKey).toList();
    final totalExp = logs.fold<int>(0, (p, e) => p + e.totalExpensesMinor);
    final totalEarn = logs.fold<int>(0, (p, e) => p + e.totalEarningsMinor);
    final net = totalEarn - totalExp;

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Month: $monthKey", style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 12),
          _kpi("Days Logged", logs.length.toString()),
          _kpi("Total Earnings", (totalEarn/100).toStringAsFixed(2)),
          _kpi("Total Expenses", (totalExp/100).toStringAsFixed(2)),
          _kpi("Net Earning", (net/100).toStringAsFixed(2), color: net>=0?Colors.green:Colors.red),
          const SizedBox(height: 12),
          const Text("Daily Nets:"),
          const SizedBox(height: 8),
          Expanded(
            child: ListView.separated(
              itemCount: logs.length,
              separatorBuilder: (_, __) => const Divider(height: 0),
              itemBuilder: (context, i) {
                final l = logs[i];
                final n = l.net/100.0;
                return ListTile(
                  title: Text(l.date.toLocal().toString().split(' ').first),
                  trailing: Text((n>=0?'+':'') + n.toStringAsFixed(2),
                    style: TextStyle(color: n>=0?Colors.green:Colors.red)),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _kpi(String label, String value, {Color? color}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label),
          Text(value, style: TextStyle(fontWeight: FontWeight.w600, color: color)),
        ],
      ),
    );
  }
}
