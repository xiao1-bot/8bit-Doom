import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';
import '../models/models.dart';

class MaintenanceScreen extends StatefulWidget {
  final Car car;
  final String monthKey;
  const MaintenanceScreen({super.key, required this.car, required this.monthKey});

  @override
  State<MaintenanceScreen> createState() => _MaintenanceScreenState();
}

class _MaintenanceScreenState extends State<MaintenanceScreen> {
  Maintenance? _m;

  @override
  void initState() {
    super.initState();
    final box = Hive.box<Maintenance>('maint');
    _m = box.values.firstWhere(
      (e) => e.carId == widget.car.id && e.month == widget.monthKey,
      orElse: () => Maintenance(id: const Uuid().v4(), carId: widget.car.id, month: widget.monthKey));
  }

  @override
  Widget build(BuildContext context) {
    final maintBox = Hive.box<Maintenance>('maint');
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Month-end maintenance", style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          ..._m!.items.asMap().entries.map((e) => _itemRow(e.key, e.value)),
          const SizedBox(height: 8),
          TextButton.icon(
            onPressed: () => setState(() => _m!.items.add(MaintenanceItem(category: 'Other', amountMinor: 0))),
            icon: const Icon(Icons.add),
            label: const Text('Add Item'),
          ),
          const Divider(),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text("Maintenance Total"),
              Text((_m!.totalMaintenanceMinor/100).toStringAsFixed(2)),
            ],
          ),
          const SizedBox(height: 8),
          FilledButton(
            onPressed: () {
              maintBox.put(_m!.id, _m!);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Saved maintenance'))
              );
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  Widget _itemRow(int index, MaintenanceItem item) {
    final cat = TextEditingController(text: item.category);
    final label = TextEditingController(text: item.label ?? '');
    final amt = TextEditingController(text: (item.amountMinor/100).toStringAsFixed(2));
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          SizedBox(width: 110, child: TextField(
            controller: cat, decoration: const InputDecoration(labelText: 'Category'),
            onChanged: (v) => item.category = v,)),
          const SizedBox(width: 8),
          Expanded(child: TextField(
            controller: label, decoration: const InputDecoration(labelText: 'Label (optional)'),
            onChanged: (v) => item.label = v.isEmpty ? null : v,)),
          const SizedBox(width: 8),
          SizedBox(width: 110, child: TextField(
            controller: amt, decoration: const InputDecoration(labelText: 'Amount'),
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            onChanged: (v) {
              final parsed = double.tryParse(v.replaceAll(',', '')) ?? 0.0;
              item.amountMinor = (parsed * 100).round();
              setState(() {});
            },)),
          IconButton(onPressed: () {
            setState(() { _m!.items.removeAt(index); });
          }, icon: const Icon(Icons.delete_outline))
        ],
      ),
    );
  }
}
